import com.aliasi.chunk.Chunking;
import com.aliasi.chunk.NBestChunker;

import com.aliasi.util.AbstractExternalizable;
import com.aliasi.util.ScoredObject;

import java.io.File;

import java.util.Iterator;

public class RunNBestChunker {


    static final int MAX_N_BEST = 8;

    public static void main(String[] args) throws Exception {
	File modelFile = new File(args[0]);

	System.out.println("Reading chunker from file=" + modelFile);
	NBestChunker chunker 
	    = (NBestChunker) AbstractExternalizable.readObject(modelFile);

	for (int i = 1; i < args.length; ++i) {
	    char[] cs = args[i].toCharArray();
	    Iterator it = chunker.nBest(cs,0,cs.length,MAX_N_BEST);
	    System.out.println(args[i]);
	    for (int n = 0; it.hasNext(); ++n) {
		ScoredObject so = (ScoredObject) it.next();
		double jointProb = so.score();
		Chunking chunking = (Chunking) so.getObject();
		System.out.println(n + " " + jointProb 
				   + " " + chunking.chunkSet());
	    }
	    System.out.println();
	}
    }
}
