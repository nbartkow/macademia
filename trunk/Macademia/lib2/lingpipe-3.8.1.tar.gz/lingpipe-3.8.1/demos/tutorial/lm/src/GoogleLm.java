import com.aliasi.io.FileExtensionFilter;

import com.aliasi.lm.TokenizedLM;

import com.aliasi.tokenizer.IndoEuropeanTokenizerFactory;
import com.aliasi.tokenizer.TokenizerFactory;

import com.aliasi.util.Strings;

import java.io.*;
import java.util.zip.*;

public class GoogleLm {

    static final int MIN_COUNT = 1000;

    static long sNumLines = 0L;

    public static void main(String[] args) throws Exception {
	File dataDir = new File(args[0]);
	
	System.out.println("Data directory=" + dataDir.getCanonicalPath());

	File bigramDir = new File(dataDir,"2gms");
	File[] bigramFiles 
	    = bigramDir.listFiles(new FileExtensionFilter("gz"));

	System.out.println("Number of files=" + bigramFiles.length);

	TokenizerFactory tf = IndoEuropeanTokenizerFactory.INSTANCE;
	TokenizedLM lm = new TokenizedLM(tf,2);
	for (int i = 0; i < bigramFiles.length; ++i)
	    train(bigramFiles[i],lm);

	System.out.println("#bigrams=" + sNumLines);
    }

    static void train(File trainingFile, TokenizedLM lm) throws Exception {
	System.out.println("Training file=" + trainingFile);
	FileInputStream fileIn = new FileInputStream(trainingFile);
	GZIPInputStream gzIn = new GZIPInputStream(fileIn);
	InputStreamReader reader = new InputStreamReader(gzIn,Strings.UTF8);
	BufferedReader bufReader = new BufferedReader(reader);
	String line;
	while ((line = bufReader.readLine()) !=null)
	    trainLine(line,lm);
    }

    static void trainLine(String line, TokenizedLM lm) {
	if (line.indexOf("S>") >= 0 
	    || line.indexOf("UNK>") >= 0) return;
	int splitIdx = line.lastIndexOf('\t');
	if (splitIdx < 0) return;
	String countString = line.substring(splitIdx+1);
	long count = Long.valueOf(countString);
	if (count > Integer.MAX_VALUE) {
	    System.out.println("big count: " + line);
	    return;
	}
	if (count < MIN_COUNT) return;
	String nGram = line.substring(0,splitIdx);
	lm.trainSequence(nGram,(int)count);
	if (++sNumLines % 1000000 == 0)
	    System.out.println("ngrams=" + sNumLines);
    }

}