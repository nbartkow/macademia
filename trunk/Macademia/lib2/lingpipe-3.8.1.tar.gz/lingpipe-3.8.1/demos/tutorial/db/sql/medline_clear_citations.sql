USE medline;

SELECT COUNT(*) FROM citation;
DELETE FROM citation;
SELECT COUNT(*) FROM citation;

