USE medline;

SELECT COUNT(*) FROM mention;
DELETE FROM mention;
SELECT COUNT(*) FROM mention;

SELECT COUNT(*) FROM sentence;
DELETE FROM sentence;
SELECT COUNT(*) FROM sentence;

