import com.aliasi.classify.Classification;
import com.aliasi.classify.Classifier;
import com.aliasi.classify.ClassifierEvaluator;

import com.aliasi.util.AbstractExternalizable;
import com.aliasi.util.Files;
import com.aliasi.util.Strings;

import java.io.*;

public class EvalLanguageId {

    // java EvalLanguageId <corpusDir>: dir
    //                     <modelFile>:file 
    //                     <trainSize>:int
    //                     <testSize>:int
    //                     <numTestsPerCat>:int
    public static void main(String[] args) throws Exception {
        File dataDir = new File(args[0]);
        File modelFile = new File(args[1]);
        int numChars = Integer.valueOf(args[2]);
        int testSize = Integer.valueOf(args[3]);
        int numTests = Integer.valueOf(args[4]);

        char[] csBuf = new char[testSize];
        
        String[] categories = dataDir.list();

        boolean boundSequences = false;

        System.out.println("Reading classifier from file=" + modelFile);
        @SuppressWarnings("unchecked") // required for deserialization
        Classifier<CharSequence,Classification> classifier 
            = (Classifier<CharSequence,Classification>) 
            AbstractExternalizable.readObject(modelFile);

        ClassifierEvaluator<CharSequence,Classification> evaluator
            = new ClassifierEvaluator<CharSequence,Classification>(classifier,categories);

        for (int i = 0; i < categories.length; ++i) {
            String category = categories[i];
            System.out.println("Evaluating category=" + category);
	    File trainingFile = new File(new File(dataDir,category),
					 category + ".txt");
	    FileInputStream fileIn 
		= new FileInputStream(trainingFile);
	    InputStreamReader reader
		= new InputStreamReader(fileIn,Strings.UTF8);

	    reader.skip(numChars); // skip training data

	    for (int k = 0; k < numTests; ++k) {
		reader.read(csBuf);
		evaluator.addCase(category, new String(csBuf));
	    }
	    reader.close();
	}

        System.out.println("TEST RESULTS");
        System.out.println(evaluator.toString());
    }

}
