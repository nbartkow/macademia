import java.util.List;

import de.tudarmstadt.ukp.wiki.parser.ParsedPage;
import de.tudarmstadt.ukp.wiki.parser.Section;
import de.tudarmstadt.ukp.wiki.parser.mediawiki.MediaWikiParser;
import de.tudarmstadt.ukp.wiki.parser.mediawiki.MediaWikiParserFactory;
import de.tudarmstadt.ukp.wikipedia.api.DatabaseConfiguration;
import de.tudarmstadt.ukp.wikipedia.api.Page;
import de.tudarmstadt.ukp.wikipedia.api.Wikipedia;
import de.tudarmstadt.ukp.wikipedia.api.WikiConstants.Language;
import de.tudarmstadt.ukp.wikipedia.api.exception.WikiApiException;

/**
 * Displays the titles of the sections found in the page <i>Dog</i>.<br>
 */
public class T4_InterfacingWithWikipedia {

	public static void main(String[] args) throws WikiApiException {
		//db connection settings
		DatabaseConfiguration dbConfig = new DatabaseConfiguration();
        dbConfig.setDatabase("DATABASE");
        dbConfig.setHost("HOST");
        dbConfig.setUser("USER");
        dbConfig.setPassword("PASSWORD");
        dbConfig.setLanguage(Language.english);
		
		//initialize a wiki
		Wikipedia wiki = new Wikipedia(dbConfig);
		
		//get the page 'Dog'
		Page p = wiki.getPage("Dog");
		
		//get a ParsedPage object
		MediaWikiParserFactory pf = new MediaWikiParserFactory();
		MediaWikiParser parser = pf.createParser();
		ParsedPage pp = parser.parse(p.getText());
	
		//get the sections of the page
		List<Section> sections = pp.getSections();
		
		for(Section section : sections) {
            System.out.println(section.getTitle());
        }
	}
}
