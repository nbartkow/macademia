import java.io.IOException;

import de.tudarmstadt.ukp.wiki.parser.ParsedPage;
import de.tudarmstadt.ukp.wiki.parser.Section;
import de.tudarmstadt.ukp.wiki.parser.mediawiki.MediaWikiParser;
import de.tudarmstadt.ukp.wiki.parser.mediawiki.MediaWikiParserFactory;
import de.tudarmstadt.ukp.wikipedia.api.exception.WikiApiException;

/**
 * Displays informations about the inner structure of a page.
 *
 */
public class T1_SimpleParserDemo {

	/**
	 * @param args
	 * @throws WikiApiException 
	 * @throws IOException 
	 */
	public static void main(String[] args) throws IOException {

        // load a sample document (the contents are equal to "DarmstadtWikipediaArticle.txt")
        String documentText = TestFile.getFileText();

        //get a ParsedPage object
		MediaWikiParserFactory pf = new MediaWikiParserFactory();
		MediaWikiParser parser = pf.createParser();
		ParsedPage pp = parser.parse(documentText);
		
		//get the sections
		for(Section section : pp.getSections()) {
			System.out.println("section : " + section.getTitle());
			System.out.println(" nr of paragraphs      : " + section.nrOfParagraphs());
			System.out.println(" nr of tables          : " + section.nrOfTables());
			System.out.println(" nr of nested lists    : " + section.nrOfNestedLists());
			System.out.println(" nr of definition lists: " + section.nrOfDefinitionLists());
		}
	}
}
