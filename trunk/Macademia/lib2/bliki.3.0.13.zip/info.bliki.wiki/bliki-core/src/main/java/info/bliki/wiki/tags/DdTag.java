package info.bliki.wiki.tags;


public class DdTag extends HTMLBlockTag {
	public DdTag() {
		super("dd", "|dl|");
	}
}