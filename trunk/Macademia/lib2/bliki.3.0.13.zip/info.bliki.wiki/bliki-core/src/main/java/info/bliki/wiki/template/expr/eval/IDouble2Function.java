package info.bliki.wiki.template.expr.eval;


public interface IDouble2Function {
  public double evaluate(double arg1, double arg2);
}
