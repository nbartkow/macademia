package info.bliki.html.wikipedia;

import info.bliki.htmlcleaner.TagNode;


public class ThTag extends ConvertEmptyHTMLTag {

	@Override
	public void open(TagNode node, StringBuilder resultBuffer) {
		resultBuffer.append("\n!");
	}

}
