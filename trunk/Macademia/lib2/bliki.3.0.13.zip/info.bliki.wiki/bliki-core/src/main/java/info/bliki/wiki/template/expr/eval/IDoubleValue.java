package info.bliki.wiki.template.expr.eval;

public interface IDoubleValue {

	public abstract double getValue();

	public abstract void setValue(double value);

}